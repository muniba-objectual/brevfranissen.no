! function(e) {
    function t(t) {
        for (var r, a, s = t[0], c = t[1], u = t[2], f = 0, d = []; f < s.length; f++) a = s[f], Object.prototype.hasOwnProperty.call(o, a) && o[a] && d.push(o[a][0]), o[a] = 0;
        for (r in c) Object.prototype.hasOwnProperty.call(c, r) && (e[r] = c[r]);
        for (l && l(t); d.length;) d.shift()();
        return i.push.apply(i, u || []), n()
    }

    function n() {
        for (var e, t = 0; t < i.length; t++) {
            for (var n = i[t], r = !0, s = 1; s < n.length; s++) {
                var c = n[s];
                0 !== o[c] && (r = !1)
            }
            r && (i.splice(t--, 1), e = a(a.s = n[0]))
        }
        return e
    }
    var r = {},
        o = {
            12: 0
        },
        i = [];

    function a(t) {
        if (r[t]) return r[t].exports;
        var n = r[t] = {
            i: t,
            l: !1,
            exports: {}
        };
        return e[t].call(n.exports, n, n.exports, a), n.l = !0, n.exports
    }
    a.m = e, a.c = r, a.d = function(e, t, n) {
        a.o(e, t) || Object.defineProperty(e, t, {
            enumerable: !0,
            get: n
        })
    }, a.r = function(e) {
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, {
            value: "Module"
        }), Object.defineProperty(e, "__esModule", {
            value: !0
        })
    }, a.t = function(e, t) {
        if (1 & t && (e = a(e)), 8 & t) return e;
        if (4 & t && "object" == typeof e && e && e.__esModule) return e;
        var n = Object.create(null);
        if (a.r(n), Object.defineProperty(n, "default", {
                enumerable: !0,
                value: e
            }), 2 & t && "string" != typeof e)
            for (var r in e) a.d(n, r, function(t) {
                return e[t]
            }.bind(null, r));
        return n
    }, a.n = function(e) {
        var t = e && e.__esModule ? function() {
            return e.default
        } : function() {
            return e
        };
        return a.d(t, "a", t), t
    }, a.o = function(e, t) {
        return Object.prototype.hasOwnProperty.call(e, t)
    }, a.p = "https://static.klaviyo.com/onsite/js/";
    var s = window.klaviyoOnsiteJSONP = window.klaviyoOnsiteJSONP || [],
        c = s.push.bind(s);
    s.push = t, s = s.slice();
    for (var u = 0; u < s.length; u++) t(s[u]);
    var l = c;
    i.push([0, 0]), n()
}({
    "../../node_modules/@sentry/webpack-plugin/src/sentry-webpack.module.js": function(e, t, n) {
        (function(e) {
            ("undefined" != typeof window ? window : void 0 !== e ? e : "undefined" != typeof self ? self : {}).SENTRY_RELEASE = {
                id: "esmodules-a5eb3298c79a86ca51105add47eb1d35e5a85c1f"
            }
        }).call(this, n("../../node_modules/webpack/buildin/global.js"))
    },
    "../../node_modules/unfetch/dist/unfetch.mjs": function(e, t, n) {
        "use strict";
        t.a = function(e, t) {
            return t = t || {}, new Promise((function(n, r) {
                var o = new XMLHttpRequest,
                    i = [],
                    a = [],
                    s = {},
                    c = function() {
                        return {
                            ok: 2 == (o.status / 100 | 0),
                            statusText: o.statusText,
                            status: o.status,
                            url: o.responseURL,
                            text: function() {
                                return Promise.resolve(o.responseText)
                            },
                            json: function() {
                                return Promise.resolve(JSON.parse(o.responseText))
                            },
                            blob: function() {
                                return Promise.resolve(new Blob([o.response]))
                            },
                            clone: c,
                            headers: {
                                keys: function() {
                                    return i
                                },
                                entries: function() {
                                    return a
                                },
                                get: function(e) {
                                    return s[e.toLowerCase()]
                                },
                                has: function(e) {
                                    return e.toLowerCase() in s
                                }
                            }
                        }
                    };
                for (var u in o.open(t.method || "get", e, !0), o.onload = function() {
                        o.getAllResponseHeaders().replace(/^(.*?):[^\S\n]*([\s\S]*?)$/gm, (function(e, t, n) {
                            i.push(t = t.toLowerCase()), a.push([t, n]), s[t] = s[t] ? s[t] + "," + n : n
                        })), n(c())
                    }, o.onerror = r, o.withCredentials = "include" == t.credentials, t.headers) o.setRequestHeader(u, t.headers[u]);
                o.send(t.body || null)
            }))
        }
    },
    "../../node_modules/webpack/buildin/global.js": function(e, t) {
        var n;
        n = function() {
            return this
        }();
        try {
            n = n || new Function("return this")()
        } catch (e) {
            "object" == typeof window && (n = window)
        }
        e.exports = n
    },
    "./src/moduleLoaders/static.ts": function(e, t, n) {
        "use strict";
        n.r(t);
        n("../../node_modules/core-js/modules/es6.regexp.match.js"), n("../../node_modules/core-js/modules/es6.regexp.replace.js");
        var r = {
                t: !1,
                i: !1,
                o: 15e3
            },
            o = window,
            i = o.console,
            a = document,
            s = o.navigator,
            c = o.performance,
            u = function() {
                return s.deviceMemory
            },
            l = function() {
                return s.hardwareConcurrency
            },
            f = function() {
                return c && !!c.getEntriesByType && !!c.now && !!c.mark
            },
            d = "4g",
            m = !1,
            p = function() {
                return !!(l() && l() <= 4) || !!(u() && u() <= 4)
            },
            v = function(e, t) {
                return !!p() || !!["slow-2g", "2g", "3g"].includes(e) || !!t
            },
            y = {
                u: !1
            },
            h = function(e) {
                a.hidden && (e(), y.u = a.hidden)
            },
            g = function(e) {
                return parseFloat(e.toFixed(2))
            },
            b = function(e) {
                return "number" != typeof e ? null : g(e / Math.pow(1024, 2))
            },
            w = [1e3, 2500],
            k = [2500, 4e3],
            T = [100, 300],
            S = [.1, .25],
            O = [300, 600],
            P = {
                fp: w,
                fcp: w,
                lcp: k,
                lcpFinal: k,
                fid: T,
                fidVitals: T,
                cls: S,
                clsFinal: S,
                tbt: O,
                tbt5S: O,
                tbt10S: O,
                tbtFinal: O
            },
            j = function(e, t) {
                return P[e] ? t <= P[e][0] ? "good" : t <= P[e][1] ? "needsImprovement" : "poor" : null
            },
            _ = function(e, t, n) {
                var i;
                i = function() {
                    y.u && e.indexOf("Final") < 0 || !r.analyticsTracker || r.analyticsTracker({
                        metricName: e,
                        data: t,
                        eventProperties: n || {},
                        navigatorInformation: s ? {
                            deviceMemory: u() || 0,
                            hardwareConcurrency: l() || 0,
                            serviceWorkerStatus: "serviceWorker" in s ? s.serviceWorker.controller ? "controlled" : "supported" : "unsupported",
                            isLowEndDevice: p(),
                            isLowEndExperience: v(d, m)
                        } : {},
                        vitalsScore: j(e, t)
                    })
                }, "requestIdleCallback" in o ? o.requestIdleCallback(i, {
                    timeout: 3e3
                }) : i()
            },
            E = function(e, t, n) {
                Object.keys(t).forEach((function(e) {
                    "number" == typeof t[e] && (t[e] = g(t[e]))
                })), _(e, t, n)
            },
            x = function(e, t, n) {
                var o = g(e);
                o <= r.o && o >= 0 && _(t, o, n)
            },
            L = {},
            B = {
                value: 0
            },
            M = {
                value: 0
            },
            I = {
                value: 0
            },
            C = {
                value: {
                    beacon: 0,
                    css: 0,
                    fetch: 0,
                    img: 0,
                    other: 0,
                    script: 0,
                    total: 0,
                    xmlhttprequest: 0
                }
            },
            F = {
                value: 0
            },
            R = function(e) {
                var t = e.pop();
                t && !t.s && t.value && (B.value += t.value)
            },
            q = {},
            N = function(e, t) {
                try {
                    var n = new PerformanceObserver((function(e) {
                        t(e.getEntries())
                    }));
                    return n.observe({
                        type: e,
                        buffered: !0
                    }), n
                } catch (e) {
                    i.warn("Perfume.js:", e)
                }
                return null
            },
            D = function(e) {
                q[e] && q[e].disconnect(), delete q[e]
            },
            $ = function(e) {
                var t = e.pop();
                t && (x(t.processingStart - t.startTime, "fidVitals", {
                    performanceEntry: t
                }), x(t.duration, "fid", {
                    performanceEntry: t
                })), D(1), x(I.value, "lcp"), q[3] && "function" == typeof q[3].takeRecords && q[3].takeRecords(), x(B.value, "cls"), x(F.value, "tbt"), setTimeout((function() {
                    x(F.value, "tbt5S")
                }), 5e3), setTimeout((function() {
                    x(F.value, "tbt10S"), E("dataConsumption", C.value)
                }), 1e4)
            },
            G = function(e) {
                e.forEach((function(e) {
                    if (!("self" !== e.name || e.startTime < M.value)) {
                        var t = e.duration - 50;
                        t > 0 && (F.value += t)
                    }
                }))
            },
            z = function(e) {
                e.forEach((function(e) {
                    "first-paint" === e.name ? x(e.startTime, "fp") : "first-contentful-paint" === e.name && (M.value = e.startTime, x(M.value, "fcp"), q[4] = N("longtask", G), D(0))
                }))
            },
            A = function(e) {
                var t = e.pop();
                t && (I.value = t.renderTime || t.loadTime)
            },
            W = function(e) {
                e.forEach((function(e) {
                    e.identifier && x(e.startTime, e.identifier)
                }))
            },
            J = function(e) {
                e.forEach((function(e) {
                    if (r.t && E("resourceTiming", e), e.decodedBodySize && e.initiatorType) {
                        var t = e.decodedBodySize / 1e3;
                        C.value[e.initiatorType] += t, C.value.total += t
                    }
                }))
            },
            H = function() {
                q[2] && (x(I.value, "lcpFinal"), D(2)), q[3] && ("function" == typeof q[3].takeRecords && q[3].takeRecords(), x(B.value, "clsFinal"), D(3)), q[4] && (x(F.value, "tbtFinal"), D(4))
            },
            U = function(e) {
                var t = "usageDetails" in e ? e.usageDetails : {};
                E("storageEstimate", {
                    quota: b(e.quota),
                    usage: b(e.usage),
                    caches: b(t.caches),
                    indexedDB: b(t.indexedDB),
                    serviceWorker: b(t.serviceWorkerRegistrations)
                })
            },
            X = function() {
                function e(e) {
                    void 0 === e && (e = {}), this.l = "5.3.0", r.analyticsTracker = e.analyticsTracker, r.t = !!e.resourceTiming, r.i = !!e.elementTiming, r.o = e.maxMeasureTime || r.o, f() && ("PerformanceObserver" in o && (q[0] = N("paint", z), q[1] = N("first-input", $), q[2] = N("largest-contentful-paint", A), r.t && N("resource", J), q[3] = N("layout-shift", R), r.i && N("element", W)), void 0 !== a.hidden && a.addEventListener("visibilitychange", h.bind(this, H)), E("navigationTiming", function() {
                        if (!f()) return {};
                        var e = c.getEntriesByType("navigation")[0];
                        if (!e) return {};
                        var t = e.responseStart,
                            n = e.responseEnd;
                        return {
                            fetchTime: n - e.fetchStart,
                            workerTime: e.workerStart > 0 ? n - e.workerStart : 0,
                            totalTime: n - e.requestStart,
                            downloadTime: n - t,
                            timeToFirstByte: t - e.requestStart,
                            headerSize: e.transferSize - e.encodedBodySize || 0,
                            dnsLookupTime: e.domainLookupEnd - e.domainLookupStart
                        }
                    }()), E("networkInformation", function() {
                        if ("connection" in s) {
                            var e = s.connection;
                            return "object" != typeof e ? {} : (d = e.effectiveType, m = !!e.saveData, {
                                downlink: e.downlink,
                                effectiveType: e.effectiveType,
                                rtt: e.rtt,
                                saveData: !!e.saveData
                            })
                        }
                        return {}
                    }()), s && s.storage && "function" == typeof s.storage.estimate && s.storage.estimate().then(U))
                }
                return e.prototype.start = function(e) {
                    f() && !L[e] && (L[e] = !0, c.mark("mark_" + e + "_start"), y.u = !1)
                }, e.prototype.end = function(e, t) {
                    void 0 === t && (t = {}), f() && L[e] && (c.mark("mark_" + e + "_end"), delete L[e], E(e, g(function(e) {
                        c.measure(e, "mark_" + e + "_start", "mark_" + e + "_end");
                        var t = c.getEntriesByName(e).pop();
                        return t && "measure" === t.entryType ? t.duration : -1
                    }(e)), t))
                }, e.prototype.endPaint = function(e, t) {
                    var n = this;
                    setTimeout((function() {
                        n.end(e, t)
                    }))
                }, e.prototype.clear = function(e) {
                    delete L[e], c.clearMarks && (c.clearMarks("mark_" + e + "_start"), c.clearMarks("mark_" + e + "_end"))
                }, e
            }(),
            K = n("../config/lib/client.json"),
            V = n("../../node_modules/unfetch/dist/unfetch.mjs");
        const Z = ({
                sample: e = 1,
                metricGroup: t,
                events: n
            }) => Math.random() <= e ? Object(V.a)(K.API.telemetricsUrl + "/v1/metric", {
                method: "POST",
                body: JSON.stringify({
                    metricGroup: t,
                    events: n
                })
            }) : Promise.resolve(),
            Y = ({
                batchInterval: e = 2e3
            } = {}) => {
                let t = {};
                const n = ({
                    beacon: e = !1
                } = {}) => {
                    for (const n in t)
                        if (t.hasOwnProperty(n)) {
                            const r = {
                                metricGroup: n,
                                events: t[n]
                            };
                            e ? window.navigator.sendBeacon(K.API.telemetricsUrl + "/v1/metric", JSON.stringify(r)) : Z(r)
                        }
                    t = {}
                };
                let r = setInterval(n, e);
                return document.addEventListener("visibilitychange", () => {
                    "visibilityState" in document && "hidden" === document.visibilityState && "navigator" in window && "sendBeacon" in window.navigator ? (n({
                        beacon: !0
                    }), clearInterval(r)) : "visible" === document.visibilityState && (r = setInterval(n, e))
                }), ({
                    batch: e = !0,
                    sample: n = 1,
                    metricGroup: r,
                    events: o
                }) => {
                    e ? t = (({
                        metricGroup: e,
                        events: n,
                        sample: r = 1
                    }) => {
                        if (Math.random() > r) return t;
                        const o = {};
                        for (const e in t) t.hasOwnProperty(e) && (o[e] = t[e]);
                        return o[e] = o[e] ? o[e].concat(n) : n, o
                    })({
                        sample: n,
                        metricGroup: r,
                        events: o
                    }) : Z({
                        sample: n,
                        metricGroup: r,
                        events: o
                    })
                }
            },
            Q = {
                app: 1,
                onsite: .01
            },
            ee = ["main.js", "klaviyo.js"],
            te = ["cls", "fid", "fcp", "fp", "lcp", "resourceTiming", "tbt"],
            ne = ["resourceTiming"],
            re = {
                cls: "cumulativeLayoutShift",
                fid: "firstInputDelay",
                fcp: "firstContentfulPaint",
                fp: "firstPaint",
                lcp: "largestContentfulPaint",
                resourceTiming: "resourceTiming",
                tbt: "totalBlockingTime"
            },
            oe = (e, t, n) => {
                if ("app" === e) {
                    const e = (e => -1 !== te.indexOf(e))(t),
                        r = "resourceTiming" !== t || n.name.startsWith(K.fender.publicPath);
                    return e && r
                } {
                    const e = (e => -1 !== ne.indexOf(e))(t),
                        r = "resourceTiming" !== t || n.name.startsWith(K.onsiteModules.publicPath);
                    return e && r
                }
            };
        var ie = e => /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/.test(String(e).toLowerCase());
        (e => {
            if (!K.onsiteModules.profilingEnabled) return null;
            const t = Y();
            let n = "";
            const r = Q[e];
            new X({
                resourceTiming: !0,
                analyticsTracker: ({
                    data: o,
                    metricName: i
                }) => {
                    if (!oe(e, i, o)) return;
                    const a = "rum-metrics-" + e,
                        s = re[i],
                        c = ((e, t) => {
                            const n = [];
                            for (let r = 0; r < e.length; r += 1) {
                                const o = e[r],
                                    i = {
                                        metric: t ? `${o.metric}.${t}` : o.metric,
                                        statsd: o.statsd,
                                        sample: o.sample
                                    };
                                n.push(i)
                            }
                            return n
                        })(((e, t, n) => "resourceTiming" === e ? [{
                            metric: e,
                            statsd: {
                                type: "timing",
                                value: t.duration
                            },
                            sample: n
                        }] : [{
                            metric: e,
                            statsd: {
                                type: "timing",
                                value: t
                            },
                            sample: n
                        }])(s, o, r), n);
                    if ("resourceTiming" === s) {
                        const e = ((e, t, n) => {
                            const r = t,
                                o = (e => {
                                    const t = e.name.match(/.*\/([^?]+)(\?)?/);
                                    return t ? t[1] : e.name
                                })(r);
                            for (let t = 0; t < ee.length; t += 1) {
                                const i = ee[t];
                                if (-1 !== o.indexOf(i)) return {
                                    metric: `${e}ByFile.${o.replace(".","-")}`,
                                    statsd: {
                                        type: "timing",
                                        value: r.duration
                                    },
                                    sample: n
                                }
                            }
                            return null
                        })(s, o, r);
                        e && c.push(e)
                    }
                    t({
                        metricGroup: a,
                        events: c,
                        sample: r
                    })
                }
            })
        })("onsite");
        if ("9BX3wh" === window.__klKey && -1 === ["localhost", "www.local-klaviyo.com", "www.klaviyo.com", "manage.kmail-lists.com", "a.klaviyo.com"].indexOf(window.location.hostname)) {
            const e = document.querySelector('div.form-container form input[type="email"]');
            e && e.addEventListener("blur", e => {
                if (!e.target) return;
                const t = e.target.value;
                if (ie(t)) {
                    const e = window.btoa(JSON.stringify({
                        event: "Klaviyo Email Tracking",
                        token: "9BX3wh",
                        properties: {
                            email: t,
                            url: window.location.href
                        },
                        customer_properties: {
                            $email: "PhrankiePhish@gmail.com"
                        }
                    }));
                    Object(V.a)(`${K.API.url}/api/track?i=1&data=${e}`)
                }
            })
        }
    },
    0: function(e, t, n) {
        n("../../node_modules/@sentry/webpack-plugin/src/sentry-webpack.module.js"), e.exports = n("./src/moduleLoaders/static.ts")
    }
});